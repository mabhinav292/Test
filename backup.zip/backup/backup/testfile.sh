for f in *.xml
do
 echo "import /home/spadmin/ImplementerTraining/admin/backup/$f"
done
